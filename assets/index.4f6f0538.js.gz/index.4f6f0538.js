
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,Z as e,J as s,v as t,c as n,bs as l,W as o,i as d,b as m,e as u,w as i,h as c,f as r,X as f,a2 as b,R as g,S as p,g as I,m as _,ak as k,al as v,am as x}from"./index.a9c2df36.js";const j=a({name:"I18nSelector"}),w=Object.assign(j,{setup(a){const{locale:j}=e.exports.useI18n(),w=s(),y=t(),L=n((()=>l())),S=o("generateI18nTitle");function T(a){j.value=a,y.setDefaultLang(a),w.meta.title&&y.setTitle(S(w.meta.i18n,w.meta.title),!1)}return(a,e)=>{const s=k,t=v,n=x;return d(y).toolbar.enableI18n?(m(),u(n,{key:0,class:"language-container",size:"default",onCommand:T},{dropdown:i((()=>[c(t,null,{default:i((()=>[(m(!0),r(p,null,f(d(L),((a,e)=>(m(),u(s,{key:e,disabled:d(y).app.defaultLang===a.name,command:a.name},{default:i((()=>[b(g(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:i((()=>[I(a.$slots,"default")])),_:3})):_("v-if",!0)}}});export{w as _};
