
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{a8 as a,ay as e,d as s,u as r,b as t,f as d,n as l,i as o,g as n,Y as c,M as y,m as i,G as p,k as u,_ as h,q as f}from"./index.503ec71c.js";const m=f(h(s({name:"ElCard",props:a({header:{type:String,default:""},bodyStyle:{type:e([String,Object,Array]),default:""},shadow:{type:String,values:["always","hover","never"],default:"always"}}),setup(a){const e=r("card");return(a,s)=>(t(),d("div",{class:l([o(e).b(),o(e).is(`${a.shadow}-shadow`)])},[a.$slots.header||a.header?(t(),d("div",{key:0,class:l(o(e).e("header"))},[n(a.$slots,"header",{},(()=>[c(y(a.header),1)]))],2)):i("v-if",!0),p("div",{class:l(o(e).e("body")),style:u(a.bodyStyle)},[n(a.$slots,"default")],6)],2))}}),[["__file","/home/runner/work/element-plus/element-plus/packages/components/card/src/card.vue"]]));export{m as E};
