
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{r as e,a2 as a,y as l,E as t,a5 as s,f as o,h as u,w as d,i,m as n,bG as p,c4 as r,c5 as c,b as f,a1 as m,a8 as v,P as _}from"./index.fcc8a9ae.js";/* empty css                 */import{E as b}from"./index2.b12d25af.js";import"./event2.c09267d7.js";const V=m(" VueUse 官网 useClipboard "),j={key:0},k=m("复制"),x={__name:"clipboard",setup(p){const m=e(""),x=e(""),{text:y,copy:C,copied:w,isSupported:U}=a();return l(w,(e=>{e&&v.success(`复制成功：${y.value}`)})),(e,a)=>{const l=_,p=t,v=s,y=r,w=b,h=c;return f(),o("div",null,[u(y,{title:"剪贴板"},{default:d((()=>[u(v,{onClick:a[0]||(a[0]=e=>{return a="https://vueuse.org/core/useClipboard/",void window.open(a,"top");var a})},{icon:d((()=>[u(p,null,{default:d((()=>[u(l,{name:"i-ep:link"})])),_:1})])),default:d((()=>[V])),_:1})])),_:1}),i(U)?(f(),o("div",j,[u(h,{title:"输入内容，并点击复制按钮"},{default:d((()=>[u(w,{modelValue:m.value,"onUpdate:modelValue":a[2]||(a[2]=e=>m.value=e)},{append:d((()=>[u(v,{onClick:a[1]||(a[1]=e=>i(C)(m.value))},{default:d((()=>[k])),_:1})])),_:1},8,["modelValue"])])),_:1}),u(h,{title:"复制成功后可在这粘贴测试"},{default:d((()=>[u(w,{modelValue:x.value,"onUpdate:modelValue":a[3]||(a[3]=e=>x.value=e)},null,8,["modelValue"])])),_:1})])):n("v-if",!0)])}}};"function"==typeof p&&p(x);export{x as default};
