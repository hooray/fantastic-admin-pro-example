
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,cy as e,E as t,a5 as l,a4 as s,f as n,h as i,w as o,bG as c,c5 as d,b as p,R as r,W as u,i as f,a1 as m,c4 as _,P as j}from"./index.f70e8cdd.js";import"./el-tooltip.0ca4bad9.js";import y from"./alert.34888424.js";import"./el-alert.ba71e881.js";import"./el-link.2c7293aa.js";const b=m(" 搜索 "),v={__name:"icon",setup(a){const c=e.filter((a=>"ep"===a.prefix))[0];return(a,e)=>{const m=_,v=j,h=t,k=l,x=d,$=s;return p(),n("div",null,[i(y),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(h,null,{default:o((()=>[i(v,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:o((()=>[i(v,{name:"i-ep:share"})])),_:1}),i(h,null,{default:o((()=>[i(v,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:o((()=>[i(h,null,{default:o((()=>[i(v,{name:"i-ep:search"})])),_:1})])),default:o((()=>[b])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(p(!0),n(r,null,u(f(c).icons,((a,e)=>(p(),n("div",{key:e,class:"list-icon"},[i($,{class:"item",effect:"dark",content:`ep:${a}`,placement:"top"},{default:o((()=>[i(h,null,{default:o((()=>[i(v,{name:`ep:${a}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof c&&c(v);var h=a(v,[["__scopeId","data-v-51a02af7"]]);export{h as default};
