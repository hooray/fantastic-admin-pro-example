
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,f as t,h as s,w as i,bM as l,bN as n,bO as d,b as e,U as o,V as c,J as p}from"./index.14f3ec2e.js";const f={},m=a=>(o("data-v-c75d8d9e"),a=a(),c(),a),r=m((()=>p("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),u=m((()=>p("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),g=m((()=>p("p",{class:"digital-7"},"Fantastic-admin",-1))),_=m((()=>p("p",{class:"digital-7"},"1234567890,.",-1))),b=m((()=>p("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),v=m((()=>p("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof l&&l(f);const x=a(f,[["render",function(a,l){const o=n,c=d;return e(),t("div",null,[s(o,{title:"自定义字体"},{content:i((()=>[r,u])),_:1}),s(c,{title:"Digital 7"},{default:i((()=>[g,_])),_:1}),s(c,{title:"Digital 7（等宽）"},{default:i((()=>[b,v])),_:1})])}],["__scopeId","data-v-c75d8d9e"]]);export{x as default};
