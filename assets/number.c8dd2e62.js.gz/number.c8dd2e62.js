
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d7 as n,E as a,a8 as e,f as s,h as u,w as t,bN as l,bP as i,b as o,J as r,R as d,i as f,a2 as m,bO as b,Q as c}from"./index.252503d3.js";const p=m(" 1 "),_=m(" 1 "),N={__name:"number",setup(l){const m=n();function N(){m.setNumber(m.number+1)}function k(){m.setNumber(m.number-1)}return(n,l)=>{const v=b,x=c,C=a,P=e,g=i;return o(),s("div",null,[u(v,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),u(g,null,{default:t((()=>[r("div",null,"当前 badge 值："+d(f(m).number),1),u(P,{onClick:N},{icon:t((()=>[u(C,null,{default:t((()=>[u(x,{name:"i-ep:plus"})])),_:1})])),default:t((()=>[p])),_:1}),u(P,{onClick:k},{icon:t((()=>[u(C,null,{default:t((()=>[u(x,{name:"i-ep:minus"})])),_:1})])),default:t((()=>[_])),_:1})])),_:1})])}}};"function"==typeof l&&l(N);export{N as default};
