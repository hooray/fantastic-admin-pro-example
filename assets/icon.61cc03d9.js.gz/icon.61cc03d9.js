
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,cA as a,E as t,a6 as l,a5 as s,f as n,h as i,w as f,bI as o,c7 as p,b as r,S as u,X as c,i as d,a2 as m,c6 as _,Q as j}from"./index.1be4fcb7.js";import"./el-tooltip.586473e3.js";import b from"./alert.5d5e58a7.js";import"./el-alert.f4fd6f63.js";import"./el-link.59e0f21a.js";const v=m(" 搜索 "),y={__name:"icon",setup(e){const o=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,y=j,h=t,k=l,x=p,A=s;return r(),n("div",null,[i(b),i(m,{title:"图标"}),i(x,{class:"demo"},{default:f((()=>[i(h,null,{default:f((()=>[i(y,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:f((()=>[i(y,{name:"i-ep:share"})])),_:1}),i(h,null,{default:f((()=>[i(y,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:f((()=>[i(h,null,{default:f((()=>[i(y,{name:"i-ep:search"})])),_:1})])),default:f((()=>[v])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:f((()=>[(r(!0),n(u,null,c(d(o).icons,((e,a)=>(r(),n("div",{key:a,class:"list-icon"},[i(A,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:f((()=>[i(h,null,{default:f((()=>[i(y,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof o&&o(y);var h=e(y,[["__scopeId","data-v-51a02af7"]]);export{h as default};
