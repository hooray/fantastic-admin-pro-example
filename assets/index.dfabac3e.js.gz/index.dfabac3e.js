
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,A as e,v as t,b as s,f as r,h as i,w as o,i as n,R as p,m as c,S as y,U as h,V as g,Q as b,E as f,F as d}from"./index.a9c2df36.js";const l={class:"copyright"},m=(a=>(h("data-v-06b111ae"),a=a(),g(),a))((()=>d("span",null,"Copyright",-1))),v={key:0},k=["href"],_={key:1},u={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},w=a({name:"Copyright"});var x=e(Object.assign(w,{setup(a){const e=t();return(a,t)=>{const h=b,g=f;return s(),r("footer",l,[m,i(g,{size:"18px"},{default:o((()=>[i(h,{name:"i-ri:copyright-line"})])),_:1}),n(e).copyright.dates?(s(),r("span",v,p(n(e).copyright.dates),1)):c("v-if",!0),n(e).copyright.company?(s(),r(y,{key:1},[n(e).copyright.website?(s(),r("a",{key:0,href:n(e).copyright.website,target:"_blank",rel:"noopener"},p(n(e).copyright.company),9,k)):(s(),r("span",_,p(n(e).copyright.company),1))],64)):c("v-if",!0),n(e).copyright.beian?(s(),r("a",u,p(n(e).copyright.beian),1)):c("v-if",!0)])}}}),[["__scopeId","data-v-06b111ae"]]);export{x as _};
