
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as l,r as n,h as a,E as s,a1 as e,c4 as u,c5 as t,a3 as i,a5 as c,P as d}from"./index.8f9b9927.js";import f from"./index.94909372.js";var o="_example-icon_jktcf_1",p="_test1_jktcf_5",r="_a_jktcf_8",_="_test2_jktcf_14",v=l({name:"JsxExample",render(){const l=n(["file-icons:jsx","ep:element-plus"]).value.map((l=>a(s,{class:o},{default:()=>[a(d,{name:l},null)]})));let v=n(0);const m=a("p",null,[e("这也是"),a("i",null,[e("一段")]),a("b",null,[e("HTML")]),e("代码")]);return a("div",null,[a(u,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),a(t,null,{default:()=>[a("p",null,[e("调用 SvgIcon 组件")]),l,a(i,null,null),a("div",{class:p},[a("div",{class:r},null)]),a("div",{class:_},[a("div",{class:r},null)]),a(i,null,null),a(c,{onClick:()=>function(l=1){v.value+=l}(10)},{default:()=>[e("点我："),v.value]}),a("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),m,a(i,null,null),a(f,null,null)]})])}});export{v as default};
