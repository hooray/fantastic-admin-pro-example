
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,E as s,a5 as t,cl as e,cm as l,f as d,h as c,w as i,bG as n,b as o,R as r,W as f,D as u,S as m,U as v,a1 as _,c4 as b,P as p}from"./index.fcc8a9ae.js";import{E as x}from"./el-card.b7fd2f7d.js";import{E as y}from"./el-avatar.f42270c3.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(m("data-v-5b6941a3"),a=a(),v(),a))((()=>u("div",{class:"item"},[u("div",{class:"name"},"Hooray"),u("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},W=_("操作一"),w=_("操作二");"function"==typeof n&&n(g);var z=a(g,[["render",function(a,n){const m=b,v=p,_=s,g=y,z=t,k=x,D=e,G=l;return o(),d("div",null,[c(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),c(G,{gutter:20,style:{margin:"0 10px"}},{default:i((()=>[(o(),d(r,null,f(12,((a,s)=>c(D,{key:s,lg:6,md:8,sm:12},{default:i((()=>[c(k,{shadow:"hover",class:"action-card"},{default:i((()=>[u("div",h,[u("div",j,[c(g,{size:"medium"},{default:i((()=>[c(_,null,{default:i((()=>[c(v,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),u("div",H,[c(z,{text:""},{default:i((()=>[W])),_:1}),c(z,{text:""},{default:i((()=>[w])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-5b6941a3"]]);export{z as default};
