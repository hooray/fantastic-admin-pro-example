
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,E as s,a7 as t,co as e,cp as l,f as d,h as c,w as i,bP as o,b as n,N as r,Z as f,G as u,Y as m,bQ as v,L as b,O as p,P as _}from"./index.3b0b287f.js";import{E as x}from"./el-card.a69c76b1.js";import{E as y}from"./el-avatar.310feccc.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(p("data-v-9562a937"),a=a(),_(),a))((()=>u("div",{class:"item"},[u("div",{class:"name"},"Hooray"),u("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},w=m("操作一"),P=m("操作二");"function"==typeof o&&o(g);const W=a(g,[["render",function(a,o){const m=v,p=b,_=s,g=y,W=t,k=x,z=e,A=l;return n(),d("div",null,[c(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),c(A,{gutter:20,style:{margin:"0 10px"}},{default:i((()=>[(n(),d(r,null,f(12,((a,s)=>c(z,{key:s,lg:6,md:8,sm:12},{default:i((()=>[c(k,{shadow:"hover",class:"action-card"},{default:i((()=>[u("div",h,[u("div",j,[c(g,{size:"medium"},{default:i((()=>[c(_,null,{default:i((()=>[c(p,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),u("div",H,[c(W,{text:""},{default:i((()=>[w])),_:1}),c(W,{text:""},{default:i((()=>[P])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-9562a937"]]);export{W as default};
