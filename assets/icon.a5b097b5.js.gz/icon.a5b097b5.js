
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,cA as e,E as t,a6 as l,a5 as s,f as n,h as i,w as o,bI as c,c7 as d,b as p,S as r,X as u,i as f,a2 as m,c6 as _,Q as b}from"./index.8029e3e3.js";import"./el-tooltip.0ca4bad9.js";import j from"./alert.1bf7a5bd.js";import"./el-alert.cc15163a.js";import"./el-link.76aaed86.js";const v=m(" 搜索 "),y={__name:"icon",setup(a){const c=e.filter((a=>"ep"===a.prefix))[0];return(a,e)=>{const m=_,y=b,h=t,k=l,x=d,A=s;return p(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(h,null,{default:o((()=>[i(y,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:o((()=>[i(y,{name:"i-ep:share"})])),_:1}),i(h,null,{default:o((()=>[i(y,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:o((()=>[i(h,null,{default:o((()=>[i(y,{name:"i-ep:search"})])),_:1})])),default:o((()=>[v])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(p(!0),n(r,null,u(f(c).icons,((a,e)=>(p(),n("div",{key:e,class:"list-icon"},[i(A,{class:"item",effect:"dark",content:`ep:${a}`,placement:"top"},{default:o((()=>[i(h,null,{default:o((()=>[i(y,{name:`ep:${a}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof c&&c(y);var h=a(y,[["__scopeId","data-v-51a02af7"]]);export{h as default};
