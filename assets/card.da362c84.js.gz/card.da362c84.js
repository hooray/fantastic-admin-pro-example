
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,E as s,a8 as e,co as t,cp as l,f as d,h as i,w as o,bM as n,b as c,S as r,X as f,J as u,a2 as m,bN as v,Q as p,U as _,V as b}from"./index.14f3ec2e.js";import{E as x}from"./el-card.79ef033a.js";import{E as y}from"./el-avatar.b738680f.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(_("data-v-9562a937"),a=a(),b(),a))((()=>u("div",{class:"item"},[u("div",{class:"name"},"Hooray"),u("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},w=m("操作一"),W=m("操作二");"function"==typeof n&&n(g);const k=a(g,[["render",function(a,n){const m=v,_=p,b=s,g=y,k=e,z=x,A=t,I=l;return c(),d("div",null,[i(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),i(I,{gutter:20,style:{margin:"0 10px"}},{default:o((()=>[(c(),d(r,null,f(12,((a,s)=>i(A,{key:s,lg:6,md:8,sm:12},{default:o((()=>[i(z,{shadow:"hover",class:"action-card"},{default:o((()=>[u("div",h,[u("div",j,[i(g,{size:"medium"},{default:o((()=>[i(b,null,{default:o((()=>[i(_,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),u("div",H,[i(k,{text:""},{default:o((()=>[w])),_:1}),i(k,{text:""},{default:o((()=>[W])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-9562a937"]]);export{k as default};
