
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,E as s,a7 as t,co as e,cp as d,f as l,h as i,w as o,bP as n,b as c,N as r,Z as u,G as f,Y as m,bQ as v,L as p,O as _,P as b}from"./index.b5d679a7.js";import{E as x}from"./el-card.06d92eeb.js";import{E as y}from"./el-avatar.445a2888.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(_("data-v-9562a937"),a=a(),b(),a))((()=>f("div",{class:"item"},[f("div",{class:"name"},"Hooray"),f("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},w=m("操作一"),P=m("操作二");"function"==typeof n&&n(g);const W=a(g,[["render",function(a,n){const m=v,_=p,b=s,g=y,W=t,k=x,z=e,A=d;return c(),l("div",null,[i(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),i(A,{gutter:20,style:{margin:"0 10px"}},{default:o((()=>[(c(),l(r,null,u(12,((a,s)=>i(z,{key:s,lg:6,md:8,sm:12},{default:o((()=>[i(k,{shadow:"hover",class:"action-card"},{default:o((()=>[f("div",h,[f("div",j,[i(g,{size:"medium"},{default:o((()=>[i(b,null,{default:o((()=>[i(_,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),f("div",H,[i(W,{text:""},{default:o((()=>[w])),_:1}),i(W,{text:""},{default:o((()=>[P])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-9562a937"]]);export{W as default};
