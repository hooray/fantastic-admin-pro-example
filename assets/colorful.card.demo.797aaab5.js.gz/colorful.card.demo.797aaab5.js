
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as e,z as a,b as t,e as o,w as r,a1 as l,Q as n,D as d,h as s,m as f,k as c,P as i,E as u,cl as m,cm as p,f as b,bG as g,c5 as h,c4 as y}from"./index.8f9b9927.js";import{E as _}from"./el-card.f1ee2a75.js";const v={class:"num"},S={class:"tip"},k=e({name:"ColorfulCard"});var C=a(Object.assign(k,{props:{colorFrom:{type:String,default:"#843cf6"},colorTo:{type:String,default:"#759bff"},header:{type:String,default:""},num:{type:Number,default:0},tip:{type:String,default:""},icon:{type:String,default:""}},setup:e=>(a,m)=>{const p=i,b=u,g=_;return t(),o(g,{shadow:"hover",class:"mini-card",style:c({background:`linear-gradient(50deg, ${e.colorFrom}, ${e.colorTo})`})},{header:r((()=>[l(n(e.header),1)])),default:r((()=>[d("div",v,n(e.num),1),d("div",S,n(e.tip),1),e.icon?(t(),o(b,{key:0},{default:r((()=>[s(p,{name:e.icon,rotate:20},null,8,["name"])])),_:1})):f("v-if",!0)])),_:1},8,["style"])}}),[["__scopeId","data-v-ba1b9c44"]]);const j={};"function"==typeof g&&g(j);var w=a(j,[["render",function(e,a){const o=y,l=C,n=m,d=p,f=h;return t(),b("div",null,[s(o,{title:"多彩渐变卡片",content:"ColorfulCard"}),s(f,null,{default:r((()=>[s(d,{gutter:20},{default:r((()=>[s(n,{md:6},{default:r((()=>[s(l,{header:"开发文档",num:123,tip:"较上周上升50%"})])),_:1}),s(n,{md:6},{default:r((()=>[s(l,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"ep:element-plus"})])),_:1}),s(n,{md:6},{default:r((()=>[s(l,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"ri:pages-line"})])),_:1}),s(n,{md:6},{default:r((()=>[s(l,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"ep:link"})])),_:1})])),_:1})])),_:1})])}]]);export{w as default};
