
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d3 as n,E as a,a6 as e,f as s,h as u,w as t,bI as l,c7 as i,b as o,F as d,R as c,i as r,a2 as f,c6 as m,Q as b}from"./index.d45ed42d.js";const p=f(" 1 "),_=f(" 1 "),k={__name:"number",setup(l){const f=n();function k(){f.setNumber(f.number+1)}function v(){f.setNumber(f.number-1)}return(n,l)=>{const x=m,C=b,N=a,g=e,h=i;return o(),s("div",null,[u(x,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),u(h,null,{default:t((()=>[d("div",null,"当前 badge 值："+c(r(f).number),1),u(g,{onClick:k},{icon:t((()=>[u(N,null,{default:t((()=>[u(C,{name:"i-ep:plus"})])),_:1})])),default:t((()=>[p])),_:1}),u(g,{onClick:v},{icon:t((()=>[u(N,null,{default:t((()=>[u(C,{name:"i-ep:minus"})])),_:1})])),default:t((()=>[_])),_:1})])),_:1})])}}};"function"==typeof l&&l(k);export{k as default};
