
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,E as a,f as t,h as l,w as d,bN as s,bP as i,b as f,a2 as u,bO as n,Q as _}from"./index.9587bc3d.js";import{E as r}from"./el-link.1412d166.js";import o from"./alert.3569ba32.js";import"./el-alert.0e33fa9a.js";const p=u("默认链接"),c=u("主要链接"),m=u("成功链接"),b=u("警告链接"),y=u("危险链接"),g=u("信息链接"),h=u("默认链接"),j=u("主要链接"),w=u("成功链接"),k=u("警告链接"),v=u("危险链接"),x=u("信息链接"),E=u("无下划线"),A=u("有下划线"),I=u(" 编辑 "),N=u(" 查看 "),O={__name:"link",setup:e=>(e,s)=>{const u=n,O=r,P=i,Q=_,q=a;return f(),t("div",null,[l(o),l(u,{title:"文字链接"}),l(P,{title:"基础用法",class:"demo"},{default:d((()=>[l(O,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[p])),_:1}),l(O,{type:"primary"},{default:d((()=>[c])),_:1}),l(O,{type:"success"},{default:d((()=>[m])),_:1}),l(O,{type:"warning"},{default:d((()=>[b])),_:1}),l(O,{type:"danger"},{default:d((()=>[y])),_:1}),l(O,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(P,{title:"禁用状态",class:"demo"},{default:d((()=>[l(O,{disabled:""},{default:d((()=>[h])),_:1}),l(O,{type:"primary",disabled:""},{default:d((()=>[j])),_:1}),l(O,{type:"success",disabled:""},{default:d((()=>[w])),_:1}),l(O,{type:"warning",disabled:""},{default:d((()=>[k])),_:1}),l(O,{type:"danger",disabled:""},{default:d((()=>[v])),_:1}),l(O,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(P,{title:"下划线",class:"demo"},{default:d((()=>[l(O,{underline:!1},{default:d((()=>[E])),_:1}),l(O,null,{default:d((()=>[A])),_:1})])),_:1}),l(P,{title:"图标",class:"demo"},{default:d((()=>[l(O,null,{default:d((()=>[l(q,{class:"el-icon--left"},{default:d((()=>[l(Q,{name:"i-ep:edit"})])),_:1}),I])),_:1}),l(O,null,{default:d((()=>[N,l(q,{class:"el-icon--right"},{default:d((()=>[l(Q,{name:"i-ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(O);const P=e(O,[["__scopeId","data-v-526d3e59"]]);export{P as default};
