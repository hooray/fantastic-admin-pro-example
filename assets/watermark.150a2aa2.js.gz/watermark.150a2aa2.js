
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as a,c as e,f as t,h as l,w as n,bH as o,c6 as s,b as r,i as u,b8 as i,a1 as m,c5 as p}from"./index.0358e322.js";/* empty css                       *//* empty css                        */import{E as d,a as f}from"./index.a1e5346e.js";import"./event.fa25aaef.js";const c=m("开启"),b=m("关闭"),_={__name:"watermark",setup(o){const m=a(),_=e({get:function(){return m.app.enableWatermark},set:function(a){m.$patch((e=>{e.app.enableWatermark=a}))}});return(a,e)=>{const o=p,m=d,j=f,v=s;return r(),t("div",null,[l(o,{title:"页面水印",content:"在某些场景下，不希望用户将系统里的信息随意截图并转发，这时可开启页面水印，以减少这种情况发生"}),l(v,{title:"可在 src\\layout\\components\\Watermark\\index.vue 文件里定制水印文案内容"},{default:n((()=>[l(j,{modelValue:u(_),"onUpdate:modelValue":e[0]||(e[0]=a=>i(_)?_.value=a:null)},{default:n((()=>[l(m,{label:!0},{default:n((()=>[c])),_:1}),l(m,{label:!1},{default:n((()=>[b])),_:1})])),_:1},8,["modelValue"])])),_:1})])}}};"function"==typeof o&&o(_);export{_ as default};
