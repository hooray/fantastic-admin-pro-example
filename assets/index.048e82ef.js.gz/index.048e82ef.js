
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,Y as e,I as s,v as t,c as n,br as l,V as o,i as d,b as m,e as u,w as i,h as r,f as c,W as f,a1 as b,Q as g,R as p,g as I,m as _,aj as j,ak as k,al as v}from"./index.5043a866.js";const x=a({name:"I18nSelector"}),w=Object.assign(x,{setup(a){const{locale:x}=e.exports.useI18n(),w=s(),y=t(),L=n((()=>l())),T=o("generateI18nTitle");function h(a){x.value=a,y.setDefaultLang(a),w.meta.title&&y.setTitle(T(w.meta.i18n,w.meta.title),!1)}return(a,e)=>{const s=j,t=k,n=v;return d(y).toolbar.enableI18n?(m(),u(n,{key:0,class:"language-container",size:"default",onCommand:h},{dropdown:i((()=>[r(t,null,{default:i((()=>[(m(!0),c(p,null,f(d(L),((a,e)=>(m(),u(s,{key:e,disabled:d(y).app.defaultLang===a.name,command:a.name},{default:i((()=>[b(g(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:i((()=>[I(a.$slots,"default")])),_:3})):_("v-if",!0)}}});export{w as _};
