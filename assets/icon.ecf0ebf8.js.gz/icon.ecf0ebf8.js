
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as e,cy as a,E as t,a5 as l,a4 as s,f as n,h as i,w as o,bG as p,c5 as r,b as u,R as c,W as d,i as f,a1 as m,c4 as _,P as j}from"./index.21d85186.js";import"./el-tooltip.0ca4bad9.js";import y from"./alert.5a43e0ee.js";import"./el-alert.16568e62.js";import"./el-link.00ee6a59.js";const v=m(" 搜索 "),b={__name:"icon",setup(e){const p=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,b=j,h=t,k=l,x=r,$=s;return u(),n("div",null,[i(y),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(h,null,{default:o((()=>[i(b,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:o((()=>[i(b,{name:"i-ep:share"})])),_:1}),i(h,null,{default:o((()=>[i(b,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:o((()=>[i(h,null,{default:o((()=>[i(b,{name:"i-ep:search"})])),_:1})])),default:o((()=>[v])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(u(!0),n(c,null,d(f(p).icons,((e,a)=>(u(),n("div",{key:a,class:"list-icon"},[i($,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:o((()=>[i(h,null,{default:o((()=>[i(b,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof p&&p(b);var h=e(b,[["__scopeId","data-v-51a02af7"]]);export{h as default};
