
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d2 as n,E as e,a6 as a,f as s,h as u,w as t,bI as l,c7 as i,b as o,F as c,R as r,i as f,a2 as m,c6 as d,Q as b}from"./index.8029e3e3.js";const p=m(" 1 "),_=m(" 1 "),k={__name:"number",setup(l){const m=n();function k(){m.setNumber(m.number+1)}function v(){m.setNumber(m.number-1)}return(n,l)=>{const x=d,C=b,N=e,g=a,h=i;return o(),s("div",null,[u(x,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),u(h,null,{default:t((()=>[c("div",null,"当前 badge 值："+r(f(m).number),1),u(g,{onClick:k},{icon:t((()=>[u(N,null,{default:t((()=>[u(C,{name:"i-ep:plus"})])),_:1})])),default:t((()=>[p])),_:1}),u(g,{onClick:v},{icon:t((()=>[u(N,null,{default:t((()=>[u(C,{name:"i-ep:minus"})])),_:1})])),default:t((()=>[_])),_:1})])),_:1})])}}};"function"==typeof l&&l(k);export{k as default};
