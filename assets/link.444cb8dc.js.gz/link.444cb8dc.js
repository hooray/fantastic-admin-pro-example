
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,E as a,f as t,h as l,w as d,bI as s,c7 as i,b as f,a2 as u,c6 as n,Q as _}from"./index.8029e3e3.js";import{E as r}from"./el-link.76aaed86.js";import p from"./alert.1bf7a5bd.js";import"./el-alert.cc15163a.js";const o=u("默认链接"),c=u("主要链接"),m=u("成功链接"),y=u("警告链接"),b=u("危险链接"),g=u("信息链接"),h=u("默认链接"),j=u("主要链接"),v=u("成功链接"),w=u("警告链接"),k=u("危险链接"),x=u("信息链接"),E=u("无下划线"),I=u("有下划线"),A=u(" 编辑 "),Q=u(" 查看 "),q={__name:"link",setup:e=>(e,s)=>{const u=n,q=r,z=i,B=_,C=a;return f(),t("div",null,[l(p),l(u,{title:"文字链接"}),l(z,{title:"基础用法",class:"demo"},{default:d((()=>[l(q,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[o])),_:1}),l(q,{type:"primary"},{default:d((()=>[c])),_:1}),l(q,{type:"success"},{default:d((()=>[m])),_:1}),l(q,{type:"warning"},{default:d((()=>[y])),_:1}),l(q,{type:"danger"},{default:d((()=>[b])),_:1}),l(q,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(z,{title:"禁用状态",class:"demo"},{default:d((()=>[l(q,{disabled:""},{default:d((()=>[h])),_:1}),l(q,{type:"primary",disabled:""},{default:d((()=>[j])),_:1}),l(q,{type:"success",disabled:""},{default:d((()=>[v])),_:1}),l(q,{type:"warning",disabled:""},{default:d((()=>[w])),_:1}),l(q,{type:"danger",disabled:""},{default:d((()=>[k])),_:1}),l(q,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(z,{title:"下划线",class:"demo"},{default:d((()=>[l(q,{underline:!1},{default:d((()=>[E])),_:1}),l(q,null,{default:d((()=>[I])),_:1})])),_:1}),l(z,{title:"图标",class:"demo"},{default:d((()=>[l(q,null,{default:d((()=>[l(C,{class:"el-icon--left"},{default:d((()=>[l(B,{name:"i-ep:edit"})])),_:1}),A])),_:1}),l(q,null,{default:d((()=>[Q,l(C,{class:"el-icon--right"},{default:d((()=>[l(B,{name:"i-ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(q);var z=e(q,[["__scopeId","data-v-a95dd182"]]);export{z as default};
