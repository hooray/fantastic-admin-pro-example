
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{v as e,c as a,f as t,h as l,w as n,bH as o,c6 as s,b as r,i as u,b8 as i,a1 as f,c5 as m}from"./index.61feeb3e.js";/* empty css                       *//* empty css                        */import{E as p,a as d}from"./index.392386ee.js";import"./event.fa25aaef.js";const c=f("开启"),b=f("关闭"),_={__name:"watermark",setup(o){const f=e(),_=a({get:function(){return f.app.enableWatermark},set:function(e){f.$patch((a=>{a.app.enableWatermark=e}))}});return(e,a)=>{const o=m,f=p,j=d,v=s;return r(),t("div",null,[l(o,{title:"页面水印",content:"在某些场景下，不希望用户将系统里的信息随意截图并转发，这时可开启页面水印，以减少这种情况发生"}),l(v,{title:"可在 src\\layout\\components\\Watermark\\index.vue 文件里定制水印文案内容"},{default:n((()=>[l(j,{modelValue:u(_),"onUpdate:modelValue":a[0]||(a[0]=e=>i(_)?_.value=e:null)},{default:n((()=>[l(f,{label:!0},{default:n((()=>[c])),_:1}),l(f,{label:!1},{default:n((()=>[b])),_:1})])),_:1},8,["modelValue"])])),_:1})])}}};"function"==typeof o&&o(_);export{_ as default};
