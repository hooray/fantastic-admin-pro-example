
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as e,cz as a,E as t,a5 as l,a4 as s,f as n,h as i,w as o,bH as f,c6 as p,b as r,R as u,W as c,i as d,a1 as m,c5 as _,P as b}from"./index.0358e322.js";import"./el-tooltip.0ca4bad9.js";import j from"./alert.e0b2666e.js";import"./el-alert.342fe292.js";import"./el-link.b88f4b69.js";const v=m(" 搜索 "),y={__name:"icon",setup(e){const f=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,y=b,h=t,k=l,x=p,z=s;return r(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(h,null,{default:o((()=>[i(y,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:o((()=>[i(y,{name:"i-ep:share"})])),_:1}),i(h,null,{default:o((()=>[i(y,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:o((()=>[i(h,null,{default:o((()=>[i(y,{name:"i-ep:search"})])),_:1})])),default:o((()=>[v])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(r(!0),n(u,null,c(d(f).icons,((e,a)=>(r(),n("div",{key:a,class:"list-icon"},[i(z,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:o((()=>[i(h,null,{default:o((()=>[i(y,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof f&&f(y);var h=e(y,[["__scopeId","data-v-51a02af7"]]);export{h as default};
