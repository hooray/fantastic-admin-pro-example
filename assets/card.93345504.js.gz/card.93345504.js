
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,E as s,a5 as t,cl as e,cm as l,f as d,h as i,w as c,bG as n,b as o,R as r,W as f,D as u,S as m,U as v,a1 as b,c4 as _,P as p}from"./index.f897cb43.js";import{E as x}from"./el-card.d871f845.js";import{E as y}from"./el-avatar.649b1e9f.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(m("data-v-5b6941a3"),a=a(),v(),a))((()=>u("div",{class:"item"},[u("div",{class:"name"},"Hooray"),u("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},W=b("操作一"),w=b("操作二");"function"==typeof n&&n(g);var z=a(g,[["render",function(a,n){const m=_,v=p,b=s,g=y,z=t,k=x,D=e,G=l;return o(),d("div",null,[i(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),i(G,{gutter:20,style:{margin:"0 10px"}},{default:c((()=>[(o(),d(r,null,f(12,((a,s)=>i(D,{key:s,lg:6,md:8,sm:12},{default:c((()=>[i(k,{shadow:"hover",class:"action-card"},{default:c((()=>[u("div",h,[u("div",j,[i(g,{size:"medium"},{default:c((()=>[i(b,null,{default:c((()=>[i(v,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),u("div",H,[i(z,{text:""},{default:c((()=>[W])),_:1}),i(z,{text:""},{default:c((()=>[w])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-5b6941a3"]]);export{z as default};
