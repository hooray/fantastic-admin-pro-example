
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,Y as e,I as s,v as t,c as n,bn as l,V as o,i as d,b as i,e as m,w as u,h as r,f as c,W as f,a1 as b,Q as g,R as p,g as I,m as _,ah as j,ai as v,aj as x}from"./index.9bf5deda.js";const h=a({name:"I18nSelector"}),k=Object.assign(h,{setup(a){const{locale:h}=e.exports.useI18n(),k=s(),w=t(),y=n((()=>l())),L=o("generateI18nTitle");function T(a){h.value=a,w.setDefaultLang(a),k.meta.title&&w.setTitle(L(k.meta.i18n,k.meta.title),!1)}return(a,e)=>{const s=j,t=v,n=x;return d(w).toolbar.enableI18n?(i(),m(n,{key:0,class:"language-container",size:"default",onCommand:T},{dropdown:u((()=>[r(t,null,{default:u((()=>[(i(!0),c(p,null,f(d(y),((a,e)=>(i(),m(s,{key:e,disabled:d(w).app.defaultLang===a.name,command:a.name},{default:u((()=>[b(g(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:u((()=>[I(a.$slots,"default")])),_:3})):_("v-if",!0)}}});export{k as _};
