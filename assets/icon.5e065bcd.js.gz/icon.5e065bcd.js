
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,cD as a,E as t,a7 as l,a6 as s,f as n,h as i,w as o,bP as f,bR as c,b as p,N as u,Z as r,i as d,Y as m,bQ as _,L as b}from"./index.b5d679a7.js";import"./el-tooltip.89296c46.js";import j from"./alert.fb5e3806.js";import"./el-alert.74c2c762.js";import"./el-link.ab86ff3f.js";const y=m(" 搜索 "),h={__name:"icon",setup(e){const f=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,h=b,k=t,v=l,x=c,$=s;return p(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(k,null,{default:o((()=>[i(h,{name:"i-ep:edit"})])),_:1}),i(k,null,{default:o((()=>[i(h,{name:"i-ep:share"})])),_:1}),i(k,null,{default:o((()=>[i(h,{name:"i-ep:delete"})])),_:1}),i(v,{type:"primary"},{icon:o((()=>[i(k,null,{default:o((()=>[i(h,{name:"i-ep:search"})])),_:1})])),default:o((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(p(!0),n(u,null,r(d(f).icons,((e,a)=>(p(),n("div",{key:a,class:"list-icon"},[i($,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:o((()=>[i(k,null,{default:o((()=>[i(h,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof f&&f(h);const k=e(h,[["__scopeId","data-v-7366a6be"]]);export{k as default};
