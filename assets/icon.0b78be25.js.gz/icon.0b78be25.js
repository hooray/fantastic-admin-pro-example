
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as e,cy as a,E as t,a5 as l,a4 as s,f as n,h as i,w as d,bG as c,c5 as f,b as o,R as p,W as r,i as u,a1 as m,c4 as _,P as b}from"./index.9bf5deda.js";import"./el-tooltip.0ca4bad9.js";import j from"./alert.d8cd1f70.js";import"./el-alert.c9229103.js";import"./el-link.5c5fb5df.js";const y=m(" 搜索 "),v={__name:"icon",setup(e){const c=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,v=b,h=t,k=l,x=f,$=s;return o(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:d((()=>[i(h,null,{default:d((()=>[i(v,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:d((()=>[i(v,{name:"i-ep:share"})])),_:1}),i(h,null,{default:d((()=>[i(v,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:d((()=>[i(h,null,{default:d((()=>[i(v,{name:"i-ep:search"})])),_:1})])),default:d((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:d((()=>[(o(!0),n(p,null,r(u(c).icons,((e,a)=>(o(),n("div",{key:a,class:"list-icon"},[i($,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:d((()=>[i(h,null,{default:d((()=>[i(v,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof c&&c(v);var h=e(v,[["__scopeId","data-v-51a02af7"]]);export{h as default};
