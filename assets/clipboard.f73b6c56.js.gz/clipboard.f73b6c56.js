
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{r as e,a2 as a,y as l,E as t,a5 as s,f as o,h as u,w as d,i,m as n,bG as p,c4 as r,c5 as c,b as m,a1 as f,a8 as v,P as b}from"./index.95bdb5c1.js";/* empty css                 */import{E as _}from"./index2.3c86b1b9.js";import"./event2.c09267d7.js";const V=f(" VueUse 官网 useClipboard "),j={key:0},k=f("复制"),x={__name:"clipboard",setup(p){const f=e(""),x=e(""),{text:y,copy:C,copied:w,isSupported:U}=a();return l(w,(e=>{e&&v.success(`复制成功：${y.value}`)})),(e,a)=>{const l=b,p=t,v=s,y=r,w=_,h=c;return m(),o("div",null,[u(y,{title:"剪贴板"},{default:d((()=>[u(v,{onClick:a[0]||(a[0]=e=>{return a="https://vueuse.org/core/useClipboard/",void window.open(a,"top");var a})},{icon:d((()=>[u(p,null,{default:d((()=>[u(l,{name:"i-ep:link"})])),_:1})])),default:d((()=>[V])),_:1})])),_:1}),i(U)?(m(),o("div",j,[u(h,{title:"输入内容，并点击复制按钮"},{default:d((()=>[u(w,{modelValue:f.value,"onUpdate:modelValue":a[2]||(a[2]=e=>f.value=e)},{append:d((()=>[u(v,{onClick:a[1]||(a[1]=e=>i(C)(f.value))},{default:d((()=>[k])),_:1})])),_:1},8,["modelValue"])])),_:1}),u(h,{title:"复制成功后可在这粘贴测试"},{default:d((()=>[u(w,{modelValue:x.value,"onUpdate:modelValue":a[3]||(a[3]=e=>x.value=e)},null,8,["modelValue"])])),_:1})])):n("v-if",!0)])}}};"function"==typeof p&&p(x);export{x as default};
