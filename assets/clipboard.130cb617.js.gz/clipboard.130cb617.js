
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{r as e,y as a,E as l,a8 as t,f as o,h as s,w as u,i as d,m as i,bM as n,bN as p,bO as r,b as m,a2 as c,a5 as f,Q as v}from"./index.14f3ec2e.js";import{E as _}from"./el-input.36e45e3c.js";import{u as b}from"./index.04a74d21.js";import"./event.d298a7ab.js";const V=c(" VueUse 官网 useClipboard "),j={key:0},k=c("复制"),x={__name:"clipboard",setup(n){const c=e(""),x=e(""),{text:y,copy:C,copied:w,isSupported:U}=b();return a(w,(e=>{e&&f.success(`复制成功：${y.value}`)})),(e,a)=>{const n=v,f=l,b=t,y=p,w=_,h=r;return m(),o("div",null,[s(y,{title:"剪贴板"},{default:u((()=>[s(b,{onClick:a[0]||(a[0]=e=>{return a="https://vueuse.org/core/useClipboard/",void window.open(a,"top");var a})},{icon:u((()=>[s(f,null,{default:u((()=>[s(n,{name:"i-ep:link"})])),_:1})])),default:u((()=>[V])),_:1})])),_:1}),d(U)?(m(),o("div",j,[s(h,{title:"输入内容，并点击复制按钮"},{default:u((()=>[s(w,{modelValue:c.value,"onUpdate:modelValue":a[2]||(a[2]=e=>c.value=e)},{append:u((()=>[s(b,{onClick:a[1]||(a[1]=e=>d(C)(c.value))},{default:u((()=>[k])),_:1})])),_:1},8,["modelValue"])])),_:1}),s(h,{title:"复制成功后可在这粘贴测试"},{default:u((()=>[s(w,{modelValue:x.value,"onUpdate:modelValue":a[3]||(a[3]=e=>x.value=e)},null,8,["modelValue"])])),_:1})])):i("v-if",!0)])}}};"function"==typeof n&&n(x);export{x as default};
