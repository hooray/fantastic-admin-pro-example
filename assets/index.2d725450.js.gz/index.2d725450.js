
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,Z as e,B as s,v as t,c as n,bz as l,W as o,i as d,b as i,e as m,w as u,h as c,f as r,X as f,a2 as b,R as g,S as p,g as _,m as j,ai as k,aj as v,ak as I}from"./index.9587bc3d.js";const w=a({name:"I18nSelector"}),x=Object.assign(w,{setup(a){const{locale:w}=e(),x=s(),y=t(),z=n((()=>l())),L=o("generateI18nTitle");function S(a){w.value=a,y.setDefaultLang(a),x.meta.title&&y.setTitle(L(x.meta.i18n,x.meta.title),!1)}return(a,e)=>{const s=k,t=v,n=I;return d(y).toolbar.enableI18n?(i(),m(n,{key:0,class:"language-container",size:"default",onCommand:S},{dropdown:u((()=>[c(t,null,{default:u((()=>[(i(!0),r(p,null,f(d(z),((a,e)=>(i(),m(s,{key:e,disabled:d(y).app.defaultLang===a.name,command:a.name},{default:u((()=>[b(g(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:u((()=>[_(a.$slots,"default")])),_:3})):j("v-if",!0)}}});export{x as _};
