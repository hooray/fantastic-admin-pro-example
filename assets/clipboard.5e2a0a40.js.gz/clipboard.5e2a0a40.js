
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{r as e,y as a,E as l,a7 as t,f as o,h as s,w as u,i as d,m as i,bP as n,bQ as p,bR as r,b as m,Y as f,a4 as c,L as v}from"./index.3b0b287f.js";import{E as b}from"./el-input.a46c7a98.js";import{u as _}from"./index.5d155420.js";import"./event.d298a7ab.js";const V=f(" VueUse 官网 useClipboard "),j={key:0},k=f("复制"),x={__name:"clipboard",setup(n){const f=e(""),x=e(""),{text:y,copy:C,copied:w,isSupported:U}=_();return a(w,(e=>{e&&c.success(`复制成功：${y.value}`)})),(e,a)=>{const n=v,c=l,_=t,y=p,w=b,h=r;return m(),o("div",null,[s(y,{title:"剪贴板"},{default:u((()=>[s(_,{onClick:a[0]||(a[0]=e=>{return a="https://vueuse.org/core/useClipboard/",void window.open(a,"top");var a})},{icon:u((()=>[s(c,null,{default:u((()=>[s(n,{name:"i-ep:link"})])),_:1})])),default:u((()=>[V])),_:1})])),_:1}),d(U)?(m(),o("div",j,[s(h,{title:"输入内容，并点击复制按钮"},{default:u((()=>[s(w,{modelValue:f.value,"onUpdate:modelValue":a[2]||(a[2]=e=>f.value=e)},{append:u((()=>[s(_,{onClick:a[1]||(a[1]=e=>d(C)(f.value))},{default:u((()=>[k])),_:1})])),_:1},8,["modelValue"])])),_:1}),s(h,{title:"复制成功后可在这粘贴测试"},{default:u((()=>[s(w,{modelValue:x.value,"onUpdate:modelValue":a[3]||(a[3]=e=>x.value=e)},null,8,["modelValue"])])),_:1})])):i("v-if",!0)])}}};"function"==typeof n&&n(x);export{x as default};
