
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as t,a5 as a,cl as e,cm as l,f as s,h as n,w as i,bG as d,c5 as u,b as f,D as c,a1 as o,c4 as r}from"./index.f70e8cdd.js";import{i as m}from"./logo.3c3b2e9b.js";const p={},_=o(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),g=o(" 这里放页面内容 "),x={style:{display:"flex","align-item":"center","justify-content":"space-between"}},y=o(" 通过 slot 设置标题 "),b=o("还可以放置自定义按钮"),h=o(" 这里放页面内容 "),j=o(" 还可以结合 ElRow 使用 "),v=o(" 这里放页面内容 "),w=o(" 这里放页面内容 "),z=c("h1",null,"Fantastic-admin",-1),M=c("img",{src:m},null,-1),P=c("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);"function"==typeof d&&d(p);var D=t(p,[["render",function(t,d){const o=r,m=u,p=a,D=e,E=l;return f(),s("div",null,[n(o,{title:"内容块",content:"PageMain"}),n(m,null,{default:i((()=>[_])),_:1}),n(m,{title:"你可以设置一个自定义的标题"},{default:i((()=>[g])),_:1}),n(m,null,{title:i((()=>[c("div",x,[y,n(p,{size:"small"},{default:i((()=>[b])),_:1})])])),default:i((()=>[h])),_:1}),n(E,{gutter:20,style:{margin:"-10px 10px"}},{default:i((()=>[n(D,{md:8},{default:i((()=>[n(m,{style:{margin:"10px 0"}},{default:i((()=>[j])),_:1})])),_:1}),n(D,{md:8},{default:i((()=>[n(m,{style:{margin:"10px 0"}},{default:i((()=>[v])),_:1})])),_:1}),n(D,{md:8},{default:i((()=>[n(m,{style:{margin:"10px 0"}},{default:i((()=>[w])),_:1})])),_:1})])),_:1}),n(m,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[z,M,P])),_:1})])}]]);export{D as default};
