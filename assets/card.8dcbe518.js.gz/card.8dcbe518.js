
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,E as s,a6 as e,cn as t,co as d,f as l,h as i,w as c,bI as n,b as o,S as r,X as u,F as f,U as m,V as v,a2 as b,c6 as _,Q as p}from"./index.d45ed42d.js";import{E as x}from"./el-card.b38411b9.js";import{E as y}from"./el-avatar.c0e0e66c.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(m("data-v-5b6941a3"),a=a(),v(),a))((()=>f("div",{class:"item"},[f("div",{class:"name"},"Hooray"),f("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},w=b("操作一"),I=b("操作二");"function"==typeof n&&n(g);var W=a(g,[["render",function(a,n){const m=_,v=p,b=s,g=y,W=e,k=x,z=t,A=d;return o(),l("div",null,[i(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),i(A,{gutter:20,style:{margin:"0 10px"}},{default:c((()=>[(o(),l(r,null,u(12,((a,s)=>i(z,{key:s,lg:6,md:8,sm:12},{default:c((()=>[i(k,{shadow:"hover",class:"action-card"},{default:c((()=>[f("div",h,[f("div",j,[i(g,{size:"medium"},{default:c((()=>[i(b,null,{default:c((()=>[i(v,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),f("div",H,[i(W,{text:""},{default:c((()=>[w])),_:1}),i(W,{text:""},{default:c((()=>[I])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-5b6941a3"]]);export{W as default};
