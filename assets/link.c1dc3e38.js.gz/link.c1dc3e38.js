
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,E as t,f as a,h as l,w as d,bP as s,bR as f,b as i,Y as u,bQ as n,L as _}from"./index.b5d679a7.js";import{E as r}from"./el-link.ab86ff3f.js";import o from"./alert.fb5e3806.js";import"./el-alert.74c2c762.js";const p=u("默认链接"),c=u("主要链接"),m=u("成功链接"),b=u("警告链接"),y=u("危险链接"),g=u("信息链接"),h=u("默认链接"),j=u("主要链接"),w=u("成功链接"),k=u("警告链接"),v=u("危险链接"),x=u("信息链接"),E=u("无下划线"),A=u("有下划线"),I=u(" 编辑 "),L=u(" 查看 "),P={__name:"link",setup:e=>(e,s)=>{const u=n,P=r,Q=f,R=_,Y=t;return i(),a("div",null,[l(o),l(u,{title:"文字链接"}),l(Q,{title:"基础用法",class:"demo"},{default:d((()=>[l(P,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[p])),_:1}),l(P,{type:"primary"},{default:d((()=>[c])),_:1}),l(P,{type:"success"},{default:d((()=>[m])),_:1}),l(P,{type:"warning"},{default:d((()=>[b])),_:1}),l(P,{type:"danger"},{default:d((()=>[y])),_:1}),l(P,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(Q,{title:"禁用状态",class:"demo"},{default:d((()=>[l(P,{disabled:""},{default:d((()=>[h])),_:1}),l(P,{type:"primary",disabled:""},{default:d((()=>[j])),_:1}),l(P,{type:"success",disabled:""},{default:d((()=>[w])),_:1}),l(P,{type:"warning",disabled:""},{default:d((()=>[k])),_:1}),l(P,{type:"danger",disabled:""},{default:d((()=>[v])),_:1}),l(P,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(Q,{title:"下划线",class:"demo"},{default:d((()=>[l(P,{underline:!1},{default:d((()=>[E])),_:1}),l(P,null,{default:d((()=>[A])),_:1})])),_:1}),l(Q,{title:"图标",class:"demo"},{default:d((()=>[l(P,null,{default:d((()=>[l(Y,{class:"el-icon--left"},{default:d((()=>[l(R,{name:"i-ep:edit"})])),_:1}),I])),_:1}),l(P,null,{default:d((()=>[L,l(Y,{class:"el-icon--right"},{default:d((()=>[l(R,{name:"i-ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(P);const Q=e(P,[["__scopeId","data-v-526d3e59"]]);export{Q as default};
