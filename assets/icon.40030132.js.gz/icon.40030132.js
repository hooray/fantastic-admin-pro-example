
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,cA as a,E as t,a6 as l,a5 as s,f as n,h as i,w as o,bI as p,c7 as r,b as u,S as d,X as c,i as f,a2 as m,c6 as _,Q as j}from"./index.a82b8a9a.js";import"./el-tooltip.586473e3.js";import v from"./alert.25d07254.js";import"./el-alert.404e2052.js";import"./el-link.60e5287d.js";const y=m(" 搜索 "),b={__name:"icon",setup(e){const p=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,b=j,h=t,k=l,x=r,A=s;return u(),n("div",null,[i(v),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(h,null,{default:o((()=>[i(b,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:o((()=>[i(b,{name:"i-ep:share"})])),_:1}),i(h,null,{default:o((()=>[i(b,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:o((()=>[i(h,null,{default:o((()=>[i(b,{name:"i-ep:search"})])),_:1})])),default:o((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(u(!0),n(d,null,c(f(p).icons,((e,a)=>(u(),n("div",{key:a,class:"list-icon"},[i(A,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:o((()=>[i(h,null,{default:o((()=>[i(b,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof p&&p(b);var h=e(b,[["__scopeId","data-v-51a02af7"]]);export{h as default};
