
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,cy as e,E as t,a5 as l,a4 as s,f as n,h as i,w as c,bG as o,c5 as f,b as p,R as r,W as u,i as d,a1 as m,c4 as _,P as b}from"./index.f897cb43.js";import"./el-tooltip.0ca4bad9.js";import j from"./alert.c6428673.js";import"./el-alert.c1ba8334.js";import"./el-link.9db5f952.js";const y=m(" 搜索 "),v={__name:"icon",setup(a){const o=e.filter((a=>"ep"===a.prefix))[0];return(a,e)=>{const m=_,v=b,h=t,k=l,x=f,$=s;return p(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:c((()=>[i(h,null,{default:c((()=>[i(v,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:c((()=>[i(v,{name:"i-ep:share"})])),_:1}),i(h,null,{default:c((()=>[i(v,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:c((()=>[i(h,null,{default:c((()=>[i(v,{name:"i-ep:search"})])),_:1})])),default:c((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:c((()=>[(p(!0),n(r,null,u(d(o).icons,((a,e)=>(p(),n("div",{key:e,class:"list-icon"},[i($,{class:"item",effect:"dark",content:`ep:${a}`,placement:"top"},{default:c((()=>[i(h,null,{default:c((()=>[i(v,{name:`ep:${a}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof o&&o(v);var h=a(v,[["__scopeId","data-v-51a02af7"]]);export{h as default};
