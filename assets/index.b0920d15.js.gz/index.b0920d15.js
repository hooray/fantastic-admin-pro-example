
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,z as e,v as t,b as s,f as r,h as i,w as o,i as n,Q as p,m as c,R as y,S as h,U as g,P as b,E as f,D as l}from"./index.fcc8a9ae.js";const m={class:"copyright"},d=(a=>(h("data-v-06b111ae"),a=a(),g(),a))((()=>l("span",null,"Copyright",-1))),v={key:0},k=["href"],_={key:1},u={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},w=a({name:"Copyright"});var x=e(Object.assign(w,{setup(a){const e=t();return(a,t)=>{const h=b,g=f;return s(),r("footer",m,[d,i(g,{size:"18px"},{default:o((()=>[i(h,{name:"i-ri:copyright-line"})])),_:1}),n(e).copyright.dates?(s(),r("span",v,p(n(e).copyright.dates),1)):c("v-if",!0),n(e).copyright.company?(s(),r(y,{key:1},[n(e).copyright.website?(s(),r("a",{key:0,href:n(e).copyright.website,target:"_blank",rel:"noopener"},p(n(e).copyright.company),9,k)):(s(),r("span",_,p(n(e).copyright.company),1))],64)):c("v-if",!0),n(e).copyright.beian?(s(),r("a",u,p(n(e).copyright.beian),1)):c("v-if",!0)])}}}),[["__scopeId","data-v-06b111ae"]]);export{x as _};
