
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,A as e,v as t,b as s,f as i,h as r,w as o,i as n,R as p,m as c,S as y,Q as h,E as g,U as b,V as f,J as d}from"./index.14f3ec2e.js";const l={class:"copyright"},m=(a=>(b("data-v-06deabe5"),a=a(),f(),a))((()=>d("span",null,"Copyright",-1))),k={key:0},v=["href"],_={key:1},u={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},w=a({name:"Copyright"}),x=e(Object.assign(w,{setup(a){const e=t();return(a,t)=>{const b=h,f=g;return s(),i("footer",l,[m,r(f,{size:"18px"},{default:o((()=>[r(b,{name:"i-ri:copyright-line"})])),_:1}),n(e).copyright.dates?(s(),i("span",k,p(n(e).copyright.dates),1)):c("v-if",!0),n(e).copyright.company?(s(),i(y,{key:1},[n(e).copyright.website?(s(),i("a",{key:0,href:n(e).copyright.website,target:"_blank",rel:"noopener"},p(n(e).copyright.company),9,v)):(s(),i("span",_,p(n(e).copyright.company),1))],64)):c("v-if",!0),n(e).copyright.beian?(s(),i("a",u,p(n(e).copyright.beian),1)):c("v-if",!0)])}}}),[["__scopeId","data-v-06deabe5"]]);export{x as _};
