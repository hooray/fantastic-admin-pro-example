
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,cE as a,E as t,a8 as l,a7 as s,f as n,h as i,w as o,bN as f,bP as p,b as u,S as c,X as d,i as r,a2 as m,bO as _,Q as b}from"./index.252503d3.js";import"./el-tooltip.89296c46.js";import j from"./alert.2a291741.js";import"./el-alert.53d97757.js";import"./el-link.037f1cff.js";const y=m(" 搜索 "),h={__name:"icon",setup(e){const f=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,h=b,k=t,v=l,x=p,E=s;return u(),n("div",null,[i(j),i(m,{title:"图标"}),i(x,{class:"demo"},{default:o((()=>[i(k,null,{default:o((()=>[i(h,{name:"i-ep:edit"})])),_:1}),i(k,null,{default:o((()=>[i(h,{name:"i-ep:share"})])),_:1}),i(k,null,{default:o((()=>[i(h,{name:"i-ep:delete"})])),_:1}),i(v,{type:"primary"},{icon:o((()=>[i(k,null,{default:o((()=>[i(h,{name:"i-ep:search"})])),_:1})])),default:o((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:o((()=>[(u(!0),n(c,null,d(r(f).icons,((e,a)=>(u(),n("div",{key:a,class:"list-icon"},[i(E,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:o((()=>[i(k,null,{default:o((()=>[i(h,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof f&&f(h);const k=e(h,[["__scopeId","data-v-7366a6be"]]);export{k as default};
