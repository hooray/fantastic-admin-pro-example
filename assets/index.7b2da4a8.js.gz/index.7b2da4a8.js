
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as l,r as n,h as a,E as s,a1 as e,c4 as u,c5 as t,a3 as i,a5 as c,P as d}from"./index.9bf5deda.js";import r from"./index.b9107851.js";var f="_example-icon_jktcf_1",o="_test1_jktcf_5",_="_a_jktcf_8",v="_test2_jktcf_14",m=l({name:"JsxExample",render(){const l=n(["sidebar-jsx","sidebar-element"]).value.map((l=>a(s,{class:f},{default:()=>[a(d,{name:l},null)]})));let m=n(0);const p=a("p",null,[e("这也是"),a("i",null,[e("一段")]),a("b",null,[e("HTML")]),e("代码")]);return a("div",null,[a(u,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),a(t,null,{default:()=>[a("p",null,[e("这是两个 Svg Icon 图标")]),l,a(i,null,null),a("div",{class:o},[a("div",{class:_},null)]),a("div",{class:v},[a("div",{class:_},null)]),a(i,null,null),a(c,{onClick:()=>function(l=1){m.value+=l}(10)},{default:()=>[e("点我："),m.value]}),a("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),p,a(i,null,null),a(r,null,null)]})])}});export{m as default};
