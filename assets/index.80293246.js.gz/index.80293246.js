
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as l,r as n,h as s,E as a,Y as e,bT as u,bQ as t,a5 as c,a7 as i,L as d}from"./index.503ec71c.js";import o from"./index.6b465603.js";const f="_example-icon_jktcf_1",p="_test1_jktcf_5",_="_a_jktcf_8",r="_test2_jktcf_14",m=l({name:"JsxExample",render(){const l=n(["file-icons:jsx","ep:element-plus"]).value.map((l=>s(a,{class:f},{default:()=>[s(d,{name:l},null)]})));let m=n(0);const v=s("p",null,[e("这也是"),s("i",null,[e("一段")]),s("b",null,[e("HTML")]),e("代码")]);return s("div",null,[s(u,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),s(t,null,{default:()=>[s("p",null,[e("调用 SvgIcon 组件")]),l,s(c,null,null),s("div",{class:p},[s("div",{class:_},null)]),s("div",{class:r},[s("div",{class:_},null)]),s(c,null,null),s(i,{onClick:()=>function(l=1){m.value+=l}(10)},{default:()=>[e("点我："),m.value]}),s("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),v,s(c,null,null),s(o,null,null)]})])}});export{m as default};
