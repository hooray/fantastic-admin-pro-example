
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,E as s,a6 as e,cn as t,co as d,f as l,h as c,w as i,bI as n,b as o,S as r,X as f,F as u,U as m,V as v,a2 as b,c6 as _,Q as p}from"./index.1be4fcb7.js";import{E as x}from"./el-card.23d4ae8c.js";import{E as y}from"./el-avatar.6b66cd7f.js";const g={},h={class:"content"},j={class:"item"},E=(a=>(m("data-v-5b6941a3"),a=a(),v(),a))((()=>u("div",{class:"item"},[u("div",{class:"name"},"Hooray"),u("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),H={class:"action-bar"},w=b("操作一"),I=b("操作二");"function"==typeof n&&n(g);var W=a(g,[["render",function(a,n){const m=_,v=p,b=s,g=y,W=e,k=x,z=t,A=d;return o(),l("div",null,[c(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),c(A,{gutter:20,style:{margin:"0 10px"}},{default:i((()=>[(o(),l(r,null,f(12,((a,s)=>c(z,{key:s,lg:6,md:8,sm:12},{default:i((()=>[c(k,{shadow:"hover",class:"action-card"},{default:i((()=>[u("div",h,[u("div",j,[c(g,{size:"medium"},{default:i((()=>[c(b,null,{default:i((()=>[c(v,{name:"i-ep:user-filled"})])),_:1})])),_:1})]),E]),u("div",H,[c(W,{text:""},{default:i((()=>[w])),_:1}),c(W,{text:""},{default:i((()=>[I])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-5b6941a3"]]);export{W as default};
