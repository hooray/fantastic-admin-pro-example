
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,Z as e,J as s,v as t,c as n,bs as l,W as o,i as d,b as m,e as i,w as u,h as c,f,X as r,a2 as b,R as g,S as p,g as _,m as k,ak as v,al as I,am as j}from"./index.1be4fcb7.js";const w=a({name:"I18nSelector"}),x=Object.assign(w,{setup(a){const{locale:w}=e(),x=s(),y=t(),L=n((()=>l())),S=o("generateI18nTitle");function T(a){w.value=a,y.setDefaultLang(a),x.meta.title&&y.setTitle(S(x.meta.i18n,x.meta.title),!1)}return(a,e)=>{const s=v,t=I,n=j;return d(y).toolbar.enableI18n?(m(),i(n,{key:0,class:"language-container",size:"default",onCommand:T},{dropdown:u((()=>[c(t,null,{default:u((()=>[(m(!0),f(p,null,r(d(L),((a,e)=>(m(),i(s,{key:e,disabled:d(y).app.defaultLang===a.name,command:a.name},{default:u((()=>[b(g(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:u((()=>[_(a.$slots,"default")])),_:3})):k("v-if",!0)}}});export{x as _};
