
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as l,r as n,h as a,E as e,a1 as s,c4 as u,c5 as t,a3 as c,a5 as i,P as d}from"./index.7b80eec3.js";import o from"./index.2766e380.js";var f="_example-icon_jktcf_1",p="_test1_jktcf_5",r="_a_jktcf_8",_="_test2_jktcf_14",v=l({name:"JsxExample",render(){const l=n(["file-icons:jsx","ep:element-plus"]).value.map((l=>a(e,{class:f},{default:()=>[a(d,{name:l},null)]})));let v=n(0);const m=a("p",null,[s("这也是"),a("i",null,[s("一段")]),a("b",null,[s("HTML")]),s("代码")]);return a("div",null,[a(u,{title:"JSX",content:"请查看本页面源码，更多 JSX 介绍请访问官网文档。"},null),a(t,null,{default:()=>[a("p",null,[s("调用 SvgIcon 组件")]),l,a(c,null,null),a("div",{class:p},[a("div",{class:r},null)]),a("div",{class:_},[a("div",{class:r},null)]),a(c,null,null),a(i,{onClick:()=>function(l=1){v.value+=l}(10)},{default:()=>[s("点我："),v.value]}),a("div",{innerHTML:"<p>这是<i>一段</i><b>HTML</b>代码</p>"},null),m,a(c,null,null),a(o,null,null)]})])}});export{v as default};
