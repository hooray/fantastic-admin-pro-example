
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,f as t,h as s,w as i,bG as l,c4 as n,c5 as e,b as c,S as d,U as o,D as f}from"./index.21d85186.js";const p={},r=a=>(d("data-v-3f528ece"),a=a(),o(),a),m=r((()=>f("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),u=r((()=>f("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),g=r((()=>f("p",{class:"digital-7"},"Fantastic-admin",-1))),_=r((()=>f("p",{class:"digital-7"},"1234567890,.",-1))),v=r((()=>f("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=r((()=>f("p",{class:"digital-7_mono"},"1234567890,.",-1)));"function"==typeof l&&l(p);var D=a(p,[["render",function(a,l){const d=n,o=e;return c(),t("div",null,[s(d,{title:"自定义字体"},{content:i((()=>[m,u])),_:1}),s(o,{title:"Digital 7"},{default:i((()=>[g,_])),_:1}),s(o,{title:"Digital 7（等宽）"},{default:i((()=>[v,b])),_:1})])}],["__scopeId","data-v-3f528ece"]]);export{D as default};
