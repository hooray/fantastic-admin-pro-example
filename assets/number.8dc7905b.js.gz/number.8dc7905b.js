
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d7 as n,E as a,a8 as e,f as s,h as u,w as t,bN as l,bP as i,b as o,J as r,R as b,i as c,a2 as d,bO as f,Q as m}from"./index.9587bc3d.js";const p=d(" 1 "),_=d(" 1 "),N={__name:"number",setup(l){const d=n();function N(){d.setNumber(d.number+1)}function k(){d.setNumber(d.number-1)}return(n,l)=>{const v=f,x=m,C=a,P=e,g=i;return o(),s("div",null,[u(v,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),u(g,null,{default:t((()=>[r("div",null,"当前 badge 值："+b(c(d).number),1),u(P,{onClick:N},{icon:t((()=>[u(C,null,{default:t((()=>[u(x,{name:"i-ep:plus"})])),_:1})])),default:t((()=>[p])),_:1}),u(P,{onClick:k},{icon:t((()=>[u(C,null,{default:t((()=>[u(x,{name:"i-ep:minus"})])),_:1})])),default:t((()=>[_])),_:1})])),_:1})])}}};"function"==typeof l&&l(N);export{N as default};
