
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as a,cA as e,E as t,a6 as l,a5 as s,f as n,h as i,w as c,bI as o,c7 as d,b as p,S as r,X as u,i as f,a2 as m,c6 as _,Q as j}from"./index.a9c2df36.js";import"./el-tooltip.0ca4bad9.js";import v from"./alert.c495661a.js";import"./el-alert.3a93e434.js";import"./el-link.dc1c61d1.js";const y=m(" 搜索 "),b={__name:"icon",setup(a){const o=e.filter((a=>"ep"===a.prefix))[0];return(a,e)=>{const m=_,b=j,h=t,k=l,x=d,A=s;return p(),n("div",null,[i(v),i(m,{title:"图标"}),i(x,{class:"demo"},{default:c((()=>[i(h,null,{default:c((()=>[i(b,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:c((()=>[i(b,{name:"i-ep:share"})])),_:1}),i(h,null,{default:c((()=>[i(b,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:c((()=>[i(h,null,{default:c((()=>[i(b,{name:"i-ep:search"})])),_:1})])),default:c((()=>[y])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:c((()=>[(p(!0),n(r,null,u(f(o).icons,((a,e)=>(p(),n("div",{key:e,class:"list-icon"},[i(A,{class:"item",effect:"dark",content:`ep:${a}`,placement:"top"},{default:c((()=>[i(h,null,{default:c((()=>[i(b,{name:`ep:${a}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof o&&o(b);var h=a(b,[["__scopeId","data-v-51a02af7"]]);export{h as default};
