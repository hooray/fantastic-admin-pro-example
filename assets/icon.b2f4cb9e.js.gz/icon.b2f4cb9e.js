
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,cA as a,E as t,a6 as l,a5 as s,f as n,h as i,w as d,bI as o,c7 as f,b as p,S as r,X as u,i as c,a2 as m,c6 as _,Q as j}from"./index.d45ed42d.js";import"./el-tooltip.586473e3.js";import b from"./alert.d8e1a1d6.js";import"./el-alert.24a2fcb4.js";import"./el-link.3ffa9be7.js";const v=m(" 搜索 "),y={__name:"icon",setup(e){const o=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const m=_,y=j,h=t,k=l,x=f,A=s;return p(),n("div",null,[i(b),i(m,{title:"图标"}),i(x,{class:"demo"},{default:d((()=>[i(h,null,{default:d((()=>[i(y,{name:"i-ep:edit"})])),_:1}),i(h,null,{default:d((()=>[i(y,{name:"i-ep:share"})])),_:1}),i(h,null,{default:d((()=>[i(y,{name:"i-ep:delete"})])),_:1}),i(k,{type:"primary"},{icon:d((()=>[i(h,null,{default:d((()=>[i(y,{name:"i-ep:search"})])),_:1})])),default:d((()=>[v])),_:1})])),_:1}),i(x,{title:"图标集合"},{default:d((()=>[(p(!0),n(r,null,u(c(o).icons,((e,a)=>(p(),n("div",{key:a,class:"list-icon"},[i(A,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:d((()=>[i(h,null,{default:d((()=>[i(y,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}};"function"==typeof o&&o(y);var h=e(y,[["__scopeId","data-v-51a02af7"]]);export{h as default};
