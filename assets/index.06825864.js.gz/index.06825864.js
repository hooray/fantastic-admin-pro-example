
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{z as a,d as s,v as e,r as o,c as t,e as l,w as n,i as r,n as i,L as d,b as c,f as u,m as b,Q as f}from"./index.40e497bb.js";import{i as p}from"./logo.3c3b2e9b.js";const m=["src"],v={key:1},g=s({name:"Logo"});var h=a(Object.assign(g,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(a){const s=e(),g=o("Fantastic-admin 专业版"),h=o(p),w=t((()=>{let a={};return s.dashboard.enable&&(a.name="dashboard"),a}));return(e,o)=>{const t=d("router-link");return c(),l(t,{to:r(w),class:i(["title",{"is-link":r(s).dashboard.enable}]),title:g.value},{default:n((()=>[a.showLogo?(c(),u("img",{key:0,src:h.value,class:"logo"},null,8,m)):b("v-if",!0),a.showTitle?(c(),u("span",v,f(g.value),1)):b("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-f6817f7e"]]);export{h as default};
