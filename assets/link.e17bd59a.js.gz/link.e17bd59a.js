
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{A as e,E as a,f as t,h as l,w as d,bM as s,bO as f,b as i,a2 as u,bN as n,Q as _}from"./index.14f3ec2e.js";import{E as r}from"./el-link.79d686df.js";import o from"./alert.380addfe.js";import"./el-alert.a1cca9c8.js";const p=u("默认链接"),c=u("主要链接"),m=u("成功链接"),y=u("警告链接"),b=u("危险链接"),g=u("信息链接"),h=u("默认链接"),j=u("主要链接"),w=u("成功链接"),k=u("警告链接"),v=u("危险链接"),x=u("信息链接"),E=u("无下划线"),A=u("有下划线"),I=u(" 编辑 "),M=u(" 查看 "),N={__name:"link",setup:e=>(e,s)=>{const u=n,N=r,O=f,Q=_,q=a;return i(),t("div",null,[l(o),l(u,{title:"文字链接"}),l(O,{title:"基础用法",class:"demo"},{default:d((()=>[l(N,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[p])),_:1}),l(N,{type:"primary"},{default:d((()=>[c])),_:1}),l(N,{type:"success"},{default:d((()=>[m])),_:1}),l(N,{type:"warning"},{default:d((()=>[y])),_:1}),l(N,{type:"danger"},{default:d((()=>[b])),_:1}),l(N,{type:"info"},{default:d((()=>[g])),_:1})])),_:1}),l(O,{title:"禁用状态",class:"demo"},{default:d((()=>[l(N,{disabled:""},{default:d((()=>[h])),_:1}),l(N,{type:"primary",disabled:""},{default:d((()=>[j])),_:1}),l(N,{type:"success",disabled:""},{default:d((()=>[w])),_:1}),l(N,{type:"warning",disabled:""},{default:d((()=>[k])),_:1}),l(N,{type:"danger",disabled:""},{default:d((()=>[v])),_:1}),l(N,{type:"info",disabled:""},{default:d((()=>[x])),_:1})])),_:1}),l(O,{title:"下划线",class:"demo"},{default:d((()=>[l(N,{underline:!1},{default:d((()=>[E])),_:1}),l(N,null,{default:d((()=>[A])),_:1})])),_:1}),l(O,{title:"图标",class:"demo"},{default:d((()=>[l(N,null,{default:d((()=>[l(q,{class:"el-icon--left"},{default:d((()=>[l(Q,{name:"i-ep:edit"})])),_:1}),I])),_:1}),l(N,null,{default:d((()=>[M,l(q,{class:"el-icon--right"},{default:d((()=>[l(Q,{name:"i-ep:view"})])),_:1})])),_:1})])),_:1})])}};"function"==typeof s&&s(N);const O=e(N,[["__scopeId","data-v-526d3e59"]]);export{O as default};
